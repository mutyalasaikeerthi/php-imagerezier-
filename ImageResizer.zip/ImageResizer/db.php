<?php
$servername = "localhost";
$username = "root"; // default username for MySQL
$password = ""; // default password for MySQL
$dbname = "keerthi";

$conn = new mysqli($servername, $username, $password, $dbname);

if(!$conn)
{
echo "connection not established";
}
else
{
echo "connection established successfully with $dbname";
}
?>