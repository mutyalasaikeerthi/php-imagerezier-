<?php
session_start();
$servername = "localhost";
$username = "root"; 
$password = "";
$dbname = "keerthi";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'];
    if ($action == 'login') {
        $username = $conn->real_escape_string($_POST['username']);
        $password = $_POST['password'];

        $sql = "SELECT * FROM user WHERE username='$username'";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
               
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['username'] = $row['username'];
                                header("Location: resize.php");
                exit;
            } else {
                echo "Invalid password.";
            }
        } else {
            echo "No user found with that username.";
        }
    }

        elseif ($action == 'signup') {
        $username = $conn->real_escape_string($_POST['username']);
        $email = $conn->real_escape_string($_POST['email']);
        $password = $_POST['password'];

                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

               $sql = "INSERT INTO user (username, email, password) VALUES ('$username', '$email', '$hashed_password')";

        if ($conn->query($sql) === TRUE) {
            echo "Signup successful!";
            header("Location: resize.php");
            exit;
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>
