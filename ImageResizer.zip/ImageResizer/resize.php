<?php
session_start();
include('db.php');

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['image'])) {
    $image = $_FILES['image']['tmp_name'];
    $new_width = intval($_POST['width']);
    $new_height = intval($_POST['height']);

    $image_info = getimagesize($image);
    if ($image_info !== false) {
        $mime_type = $image_info['mime'];

        switch ($mime_type) {
            case 'image/jpeg':
                $src = imagecreatefromjpeg($image);
                break;
            case 'image/png':
                $src = imagecreatefrompng($image);
                break;
            case 'image/gif':
                $src = imagecreatefromgif($image);
                break;
            default:
                die('Unsupported file format');
        }

        $dst = imagecreatetruecolor($new_width, $new_height);
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $new_width, $new_height, $image_info[0], $image_info[1]);

        $resized_image = 'resized_image.jpg';
        imagejpeg($dst, $resized_image);

        imagedestroy($src);
        imagedestroy($dst);

        echo '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Image Resized Successfully</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f0f0f0;
                    padding: 20px;
                }
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                    background-color: #fff;
                    padding: 20px;
                    border-radius: 5px;
                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                    text-align: center;
                }
                h1 {
                    margin-top: 0;
                }
                a {
                    display: inline-block;
                    padding: 10px 20px;
                    background-color: #4CAF50;
                    color: white;
                    text-decoration: none;
                    border-radius: 4px;
                    margin-top: 10px;
                }
                a:hover {
                    background-color: #45a049;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Image Resized Successfully</h1>
                <a href="' . $resized_image . '" download>Download Resized Image</a>
            </div>
        </body>
        </html>';
        exit();
    } else {
        echo '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Invalid Image File</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f0f0f0;
                    padding: 20px;
                }
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                    background-color: #fff;
                    padding: 20px;
                    border-radius: 5px;
                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                    text-align: center;
                }
                h1 {
                    margin-top: 0;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Invalid Image File</h1>
                <p>Please upload a valid image file (JPEG, PNG, GIF).</p>
            </div>
        </body>
        </html>';
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resize Image</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h1 {
            margin-top: 0;
        }
        form {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }
        input[type="number"], input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Resize Image</h1>
        <form action="resize.php" method="post" enctype="multipart/form-data">
            <label for="image">Select Image:</label>
            <input type="file" id="image" name="image" accept="image/*" required>
            <label for="width">New Width:</label>
            <input type="number" id="width" name="width" required>
            <label for="height">New Height:</label>
            <input type="number" id="height" name="height" required>
            <button type="submit">Resize</button>
        </form>
    </div>
</body>
</html>
